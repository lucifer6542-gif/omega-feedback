"""Remark 28: one process-function branch is not enough.
Four-party feedback whose branch o_0 = 0 has constant inputs (a process function) and whose branch o_0 = 1 is a
three-party feedback (paradox-free by Theorem 31). det V' (exact integer polynomial in t_k = tan(alpha_k/2)) takes
opposite signs at two interior rational points, so A_g has an interior zero. Expected: 'sign change: True'."""
from fractions import Fraction
import math
from fdet import detG, ctx
tables=['0011001111000011','0101000001010101','1011101111111111','1010111010101110']   # g_k(o) for o = 0..15, o = sum_k 2^k o_k
Gt=[sum(int(ch)<<o for o,ch in enumerate(s)) for s in tables]
for j in (1,2,3):
    assert len({tables[j][o] for o in range(0,16,2)})==1, "branch o_0=0 must have constant inputs"
P=detG(Gt)                      # fmpz_mpoly in t0..t3
alpha=[2.4148,1.7031,2.8357,1.7726]
base=[Fraction(math.tan(a/2)).limit_denominator(1000) for a in alpha]
def ev(pt):
    num=0
    for exps,coef in zip(P.monoms(),P.coeffs()):
        term=Fraction(int(coef))
        for e,x in zip(exps,pt): term*=x**int(e)
        num+=term
    return num
vals=[]
for d in (Fraction(-1,20),Fraction(1,20)):
    pt=list(base); pt[0]+=d; vals.append(ev(pt))
print("t at the two points:",[[str(x) for x in (base[0]+d,)+tuple(base[1:])] for d in (Fraction(-1,20),Fraction(1,20))])
print("det V' values:",[float(v) for v in vals],"  sign change:",vals[0]*vals[1]<0)
