import json, numpy as np
from lvl import Vprime_direct
rng=np.random.default_rng(5)
def restrict(g,n,k,cfun):
    # (n-1)-party feedback: o_k := cfun(o') ; parties other than k
    others=[j for j in range(n) if j!=k]; m=n-1
    out=[]
    for j in others:
        tab=np.zeros(2**m,int)
        for op in range(2**m):
            o=0
            for i,jj in enumerate(others): o|=((op>>i)&1)<<jj
            ok=cfun(o)
            tab[op]=g[j][o|(ok<<k)]
        out.append(tab)
    return out
def dV(g,n,t): return np.linalg.det(Vprime_direct(g,n,t))
if __name__=="__main__":
  for f,n in (("gen5_s1.json",5),):
     G=json.load(open(f))
     errs0=[];errsI=[]
     for gl in G[:30]:
         g=[np.array(x) for x in gl]
         for k in range(n):
             t=rng.uniform(0.2,2,n)
             t0=t.copy(); t0[k]=0
             lhs=dV(g,n,t0)
             r0=restrict(g,n,k,lambda o:0); r1=restrict(g,n,k,lambda o:1)
             tt=np.delete(t,k)
             rhs=dV(r0,n-1,tt)*dV(r1,n-1,tt)
             errs0.append(abs(abs(lhs)-abs(rhs))/max(1,abs(lhs)))
             # leading coefficient: lim det/t_k^{2m}
             big=1e3; tb=t.copy(); tb[k]=big
             vals=[dV(g,n,np.where(np.arange(n)==k,s,t)) for s in (big,2*big)]
             deg=round(np.log2(abs(vals[1]/vals[0])))
             lead=vals[0]/big**deg
             c0=restrict(g,n,k,lambda o:g[k][o]); c1=restrict(g,n,k,lambda o:1-g[k][o])
             rhs2=dV(c0,n-1,tt)*dV(c1,n-1,tt)
             errsI.append(abs(abs(lead)-abs(rhs2))/max(1,abs(lead)))
     print(f,"face alpha_k->0 identity max rel err",max(errs0)," leading-coef identity max rel err",max(errsI))
