import json, numpy as np, sys
from lvl import Vprime_direct
from ctrl import restrict
rng=np.random.default_rng(2)
def W(g,n,t):
    # rows w_r with party-k-free (n-1)-party product vectors, rotation by angle theta=atan t (normalized)
    th=np.arctan(t); N=2**n; rows=[]
    for o in range(N):
        v=np.array([1.0])
        for j in range(n):
            oj=(o>>j)&1
            if g[j][o]==0: e=np.eye(2)[oj]
            else:
                c,s=np.cos(th[j]),np.sin(th[j])
                e=np.array([c,s]) if oj==0 else np.array([-s,c])
            v=np.kron(v,e)
        rows.append(v)
    return np.array(rows)
def Kmat(g,n,k,t):
    tt=np.delete(t,k)
    g0=restrict(g,n,k,lambda o:0); g1=restrict(g,n,k,lambda o:1)
    W0=W(g0,n-1,tt); W1=W(g1,n-1,tt)
    M=W1@np.linalg.inv(W0)
    m=n-1; S=[]
    for op in range(2**m):
        o=0; others=[j for j in range(n) if j!=k]
        for i,jj in enumerate(others): o|=((op>>i)&1)<<jj
        if g[k][o]: S.append(op)
    Mi=np.linalg.inv(M)
    return M[np.ix_(S,S)]@Mi[np.ix_(S,S)], M, S
if __name__=="__main__":
    G=json.load(open(sys.argv[1])); n=int(sys.argv[2])
    err=0
    for gl in G[:15]:
        g=[np.array(x) for x in gl]
        for k in range(n):
            t=rng.uniform(0.3,2,n)
            K,M,S=Kmat(g,n,k,t)
            ev=np.linalg.eigvals(K)
            # compare: normalized det V (rows normalized) as function of u_k
            for tk in (0.4,1.3):
                t2=t.copy(); t2[k]=tk
                lhs=np.linalg.det(W(g,n,t2))
                t0=t.copy(); t0[k]=0
                base=np.linalg.det(W(g,n,t0))
                u=tk**2
                rhs=base*np.prod(1+u*ev).real/(1+u)**(len(S))
                err=max(err,abs(abs(lhs)-abs(rhs))/max(1e-12,abs(lhs)))
    print("identity det V(u_k) = det V(0) * prod(1+u*lambda_i(K)) / (1+u)^|S| : max rel err",err)
