import flint, numpy as np, time
n=4
ctx=flint.fmpz_mpoly_ctx.get(tuple('t%d'%k for k in range(n)),'lex')
T=ctx.gens()
one=ctx.from_dict({(0,)*n:1}); zero=ctx.from_dict({})
def Vrows(Gt):   # Gt: list of 16-bit tables g_k
    rows=[]
    for o in range(2**n):
        v=[one]
        for k in range(n):
            ok=(o>>k)&1
            if (Gt[k]>>o)&1==0: e=[one,zero] if ok==0 else [zero,one]
            else: e=[one,T[k]] if ok==0 else [-T[k],one]
            v=[a*b for a in v for b in e]      # party 0 most significant
        rows.append(v)
    return rows
def bareiss(M):
    M=[r[:] for r in M]; m=len(M); sign=1; prev=one
    for k in range(m-1):
        if M[k][k]==0:
            sw=next((i for i in range(k+1,m) if M[i][k]!=0),None)
            if sw is None: return zero
            M[k],M[sw]=M[sw],M[k]; sign=-sign
        for i in range(k+1,m):
            for j in range(k+1,m):
                num=M[i][j]*M[k][k]-M[i][k]*M[k][j]
                M[i][j]=num/prev if prev!=one else num
            M[i][k]=zero
        prev=M[k][k]
    return sign*M[m-1][m-1]
def detG(Gt):
    return bareiss(Vrows(Gt))
def signs(Gt):
    d=detG(Gt); cs=[int(c) for c in d.coeffs()]
    return len(cs),sum(c>0 for c in cs),sum(c<0 for c in cs),d
if __name__=="__main__":
    from detscan import affine
    for rows in ([12,12,3,3],[10,5,2,1]):
        g=affine(rows,4); Gt=[sum(int(g[k][o])<<o for o in range(16)) for k in range(4)]
        t0=time.time(); print(rows,signs(Gt)[:3],round(time.time()-t0,3))
