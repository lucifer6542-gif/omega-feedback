"""Check Theorem 24 (damped coupling) and Corollary 26 (projector form) exactly as written in the draft.
Party k = 0. Columns of W_c: w_{c,r} = (x)_{j!=0} |r_j>_{g_j(r, o_0=c)}."""
import numpy as np, itertools
rng=np.random.default_rng(1)
def ket(b,x,a):  # eigvec of A_x for outcome b; A_0=Z, A_1 at angle a
    if x==0: return np.eye(2)[b]
    c,s=np.cos(a/2),np.sin(a/2)
    return np.array([c,s]) if b==0 else np.array([-s,c])
def kron(vs):
    out=np.array([1.0])
    for v in vs: out=np.kron(out,v)
    return out
def run(n,trials=200):
    worst=0; worst18=0; tested18=0
    for _ in range(trials):
        # random feedback: g[j] maps o (tuple) -> bit, independent of o_j
        g=[]
        for j in range(n):
            tab={}
            for o in itertools.product([0,1],repeat=n):
                key=o[:j]+o[j+1:]
                if key not in tab: tab[key]=int(rng.integers(2))
            g.append(lambda o,j=j,tab=tab: tab[o[:j]+o[j+1:]])
        al=rng.uniform(0.05,np.pi-0.05,n)
        rs=list(itertools.product([0,1],repeat=n-1))
        # full V: rows = party0 basis (b) x rest ; columns ordered (o_0, r)
        cols=[]
        for c in (0,1):
            for r in rs:
                o=(c,)+r
                cols.append(kron([ket(o[j],g[j](o),al[j]) for j in range(n)]))
        V=np.array(cols).T
        W=[np.array([kron([ket(r[j-1],g[j]((c,)+r),al[j]) for j in range(1,n)]) for r in rs]).T for c in (0,1)]
        S=[i for i,r in enumerate(rs) if g[0]((0,)+r)==1]
        P=np.zeros((len(rs),len(rs))); P[S,S]=1
        K=np.linalg.solve(W[0],W[1]); cc=np.cos(al[0]/2); I=np.eye(len(rs))
        pinch=P@K@P+(I-P)@K@(I-P)
        Kc=cc*K+(1-cc)*pinch
        lhs=np.linalg.det(V); rhs=np.linalg.det(W[0])**2*np.linalg.det(Kc)
        worst=max(worst,abs(lhs-rhs)/max(1,abs(lhs)))
        # Corollary 26: det K_c = det K * det(I - s^2 (I-Q)P)
        s=np.sin(al[0]/2); Q=np.linalg.solve(K,P@K)
        d2=np.linalg.det(K)*np.linalg.det(I-s**2*(I-Q)@P)
        worst18=max(worst18,abs(d2-np.linalg.det(Kc))/max(1,abs(d2)))
    return worst,worst18
for n in (2,3,4):
    print(n, "Thm24 rel.err %.1e   Cor26 identity rel.err %.1e"%run(n))
# Corollary 26 eigenvalue claim on GHZ4 (paradox at interior angles): find alpha_0 with det V=0

# GHZ4: rows m0=m1={2,3}, m2=m3={0,1}; search offsets with det V = 0 at alpha = pi/2 for all
rows=[{2,3},{2,3},{0,1},{0,1}]
for off in itertools.product([0,1],repeat=4):
    g=[lambda o,j=j: (off[j]+sum(o[i] for i in rows[j]))%2 for j in range(4)]
    al=np.full(4,np.pi/2)
    rs=list(itertools.product([0,1],repeat=3))
    V=np.array([kron([ket(o[j],g[j](o),al[j]) for j in range(4)]) for c in (0,1) for r in rs for o in [(c,)+r]]).T
    if abs(np.linalg.det(V))<1e-12:
        W=[np.array([kron([ket(r[j-1],g[j]((c,)+r),al[j]) for j in range(1,4)]) for r in rs]).T for c in (0,1)]
        S=[i for i,r in enumerate(rs) if g[0]((0,)+r)==1]; P=np.zeros((8,8)); P[S,S]=1
        Q0=W[0]@P@np.linalg.inv(W[0]); Q1=W[1]@P@np.linalg.inv(W[1])
        ev=np.linalg.eigvals(Q0@Q1)
        print("GHZ4 offsets",off,"det V=0; eigenvalues of Q0Q1 near -cot^2(pi/4)=-1:",np.round(sorted(ev.real),6)[:3]); break
