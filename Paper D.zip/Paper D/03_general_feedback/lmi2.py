import json, numpy as np, sys, cvxpy as cp
from kred import Kmat
rng=np.random.default_rng(4)
def lmiZ(M,S):
    m=M.shape[0]; Sb=[i for i in range(m) if i not in S]
    Z=cp.Variable((m,m)); cons=[]
    for i in S:
        for j in Sb: cons+= [Z[i,j]==0, Z[j,i]==0]
    s=cp.Variable()
    Y=M@Z; cons+=[(Y+Y.T)/2>>s*np.eye(m), cp.norm(Z,"fro")<=10*m]
    pr=cp.Problem(cp.Maximize(s),cons); pr.solve(solver=cp.CLARABEL)
    return s.value
if __name__=="__main__":
  f=sys.argv[1]; n=int(sys.argv[2]); G=json.load(open(f)); lim=int(sys.argv[3])
  res=[]; perg=[]
  for gl in G[:lim]:
      g=[np.array(x) for x in gl]; okany=[]
      for k in range(n):
          t=np.tan(rng.uniform(0.05,np.pi/2-0.05,n))
          K,M,S=Kmat(g,n,k,t)
          if len(S)==0: continue
          sv=lmiZ(M,S); res.append(sv); okany.append(sv is not None and sv>1e-7)
      perg.append(any(okany))
  print(f,"cases",len(res),"feasible (MZ accretive, Z block-diag)",sum(1 for s in res if s is not None and s>1e-7),"| feasible for some k:",sum(perg),"/",len(perg))
