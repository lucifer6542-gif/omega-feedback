"""Self-contained tools for the 'level' conjecture.
g is a table g[k][o] in {0,1}, o an integer 0..2^n-1 (bit k of o = o_k), g[k] ignores bit k of o.
"""
import itertools, numpy as np
from functools import reduce

Z = np.array([[1., 0.], [0., -1.]]); X = np.array([[0., 1.], [1., 0.]]); I2 = np.eye(2)

def bit(o, k): return (o >> k) & 1

def make_g(n, rng=None, fn=None):
    """fn(k, o_tuple_without_k)->bit ; or random."""
    g = []
    for k in range(n):
        tab = np.zeros(2 ** n, dtype=int)
        base = {}
        for o in range(2 ** n):
            key = o & ~(1 << k)
            if key not in base:
                base[key] = int(rng.integers(0, 2)) if fn is None else int(fn(k, key))
            tab[o] = base[key]
        g.append(tab)
    return g

def frame_V(g, alphas, n):
    cols = []
    for o in range(2 ** n):
        vs = []
        for k in range(n):
            e = np.zeros(2); e[bit(o, k)] = 1
            if g[k][o]:
                a = alphas[k] / 2
                R = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
                e = R @ e
            vs.append(e)
        cols.append(reduce(np.kron, vs))
    return np.array(cols).T   # kron order: party 0 is the most significant tensor factor

def frame_A(g, alphas, n):
    V = frame_V(g, alphas, n)
    return V @ V.T

def fwht(a):
    a = a.astype(float).copy(); h = 1
    while h < len(a):
        for i in range(0, len(a), 2 * h):
            x = a[i:i + h].copy(); y = a[i + h:i + 2 * h].copy()
            a[i:i + h] = x + y; a[i + h:i + 2 * h] = x - y
        h *= 2
    return a

def word_coeffs(g, n):
    """returns dict (U,T) -> a_{U, T\\U} for nonempty U (bitmasks), T superset of U, nonzero only."""
    N = 2 ** n
    out = {}
    for U in range(1, N):
        par = np.zeros(N, dtype=int)
        for k in range(n):
            if (U >> k) & 1: par ^= g[k]
        f = 1 - 2 * par
        W = fwht(f) / N          # W[T] = E_o[(-1)^{o.T} f(o)]  (o.T = parity of o & T)
        for T in range(N):
            if (T & U) == U and abs(W[T]) > 1e-12:
                out[(U, T)] = W[T]
    return out

def level(g, n):
    c = word_coeffs(g, n)
    return max([bin(T).count('1') for (U, T) in c] or [0]), c

def expansion_A(g, alphas, n):
    """A = sum a_{U,V} D^U E^V  (operators, kron order party 0 most significant)."""
    D, E = [], []
    for k in range(n):
        S0 = Z; S1 = np.cos(alphas[k]) * Z + np.sin(alphas[k]) * X
        D.append((S0 - S1) / 2); E.append((S0 + S1) / 2)
    A = np.eye(2 ** n)
    for (U, T), a in word_coeffs(g, n).items():
        fac = []
        for k in range(n):
            if (U >> k) & 1: fac.append(D[k])
            elif (T >> k) & 1: fac.append(E[k])
            else: fac.append(I2)
        A = A + a * reduce(np.kron, fac)
    return A

def lam_min(g, alphas, n):
    return np.linalg.eigvalsh(frame_A(g, alphas, n))[0]

# ---- exact permutation-expansion pieces -----
def Vprime_entry(g, n, t, o, w):
    """unnormalised V'_{o,w} = prod_k [x_k=0: delta(w_k,o_k); x_k=1: t_k^{o_k xor w_k} (-1)^{o_k (1-w_k)}]"""
    val = 1.0
    for k in range(n):
        ok, wk = bit(o, k), bit(w, k)
        if g[k][o] == 0:
            if ok != wk: return 0.0
        else:
            val *= t[k] ** (ok ^ wk) * (-1) ** (ok * (1 - wk))
    return val

def Vprime_direct(g, n, t):
    cols = []
    for o in range(2 ** n):
        vs = []
        for k in range(n):
            if g[k][o] == 0:
                e = np.zeros(2); e[bit(o, k)] = 1
            else:
                e = np.array([1.0, t[k]]) if bit(o, k) == 0 else np.array([-t[k], 1.0])
            vs.append(e)
        cols.append(reduce(np.kron, vs))
    return np.array(cols)   # row o = v_o  (so entry [o, w])

if __name__ == '__main__':
    rng = np.random.default_rng(1)
    for n in (3, 4):
        err_entry = err_exp = 0.0
        for _ in range(30):
            g = make_g(n, rng)
            t = rng.uniform(0.1, 2, n)
            Vd = Vprime_direct(g, n, t)
            # kron order has party 0 as most significant, so w index uses reversed bits
            M = np.array([[Vprime_entry(g, n, t, o, w) for w in range(2 ** n)] for o in range(2 ** n)])
            # map w (bit k = party k) to kron index (party 0 most significant)
            perm = [sum(bit(w, k) << (n - 1 - k) for k in range(n)) for w in range(2 ** n)]
            Mk = np.zeros_like(M)
            for w in range(2 ** n): Mk[:, perm[w]] = M[:, w]
            err_entry = max(err_entry, np.abs(Mk - Vd).max())
            al = rng.uniform(0.1, 3.0, n)
            # expansion uses kron order party 0 most significant, bit conventions identical for A
            err_exp = max(err_exp, np.abs(expansion_A(g, al, n) - frame_A(g, al, n)).max())
        print(f"n={n}: entry-formula err {err_entry:.2e}, word-expansion err {err_exp:.2e}")
