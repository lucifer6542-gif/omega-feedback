import json, numpy as np
from kred import Kmat, W
rng=np.random.default_rng(41)
err=0; G=json.load(open("gen5_s1.json")); n=5
for gl in G[:30]:
    g=[np.array(x) for x in gl]
    for k in range(n):
        t=np.tan(rng.uniform(0.1,np.pi/2-0.1,n))
        K,M,S=Kmat(g,n,k,t)
        Sb=[i for i in range(len(M)) if i not in S]
        idx=S+Sb
        P=M[np.ix_(idx,idx)]; s=len(S)
        t0=t.copy(); t0[k]=0
        base=np.linalg.det(W(g,n,t0))
        for th in (0.3,0.9,1.4):
            t2=t.copy(); t2[k]=np.tan(th)       # theta=alpha_k/2
            c=np.cos(th)
            Mc=P.copy(); Mc[:s,s:]*=c; Mc[s:,:s]*=c
            lhs=np.linalg.det(W(g,n,t2)); rhs=base*np.linalg.det(Mc)/np.linalg.det(M)
            err=max(err,abs(lhs-rhs)/max(1e-12,abs(lhs)))
print("det V(alpha) = det V(alpha_k=0) * det(K_c)/det(K), c=cos(alpha_k/2): max rel err",err)
