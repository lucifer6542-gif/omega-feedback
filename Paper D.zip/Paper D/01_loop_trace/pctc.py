import numpy as np, itertools
from functools import reduce
rng=np.random.default_rng(7)
Z=np.diag([1.,-1]); X=np.array([[0,1.],[1,0]])
def proj(o,x,al):
    A=Z if x==0 else np.cos(al)*Z+np.sin(al)*X
    return (np.eye(2)+(-1)**o*A)/2
def run(n):
    d=2**n; al=rng.uniform(0.1,np.pi-0.1,n)
    psi=rng.normal(size=d)+1j*rng.normal(size=d); psi/=np.linalg.norm(psi)
    g=[{o:int(rng.integers(0,2)) for o in range(d)} for k in range(n)]   # arbitrary g_k(o); make it ignore o_k
    for k in range(n):
        for o in range(d):
            g[k][o]=g[k][o & ~(1<<k)]
    gx=lambda o: sum(g[k][o]<<k for k in range(n))
    bits=lambda v:[(v>>k)&1 for k in range(n)]
    # registers: R (d) , E (d) , S (d) , C' (d)  -> explicit state vector
    state=np.zeros((d,d,d,d),complex)   # [R, E, S, C']
    for x in range(d):
        for o in range(d):
            M=reduce(np.kron,[proj(bits(o)[k],bits(x)[k],al[k]) for k in range(n)][::-1])
            state[x,o,:,gx(o)]+= (M@psi)/np.sqrt(d)
    # postselect (C',R) onto Phi = sum_y |y>|y>/sqrt(d)
    post=np.einsum('yesy->es',state.transpose(0,1,2,3)[:, :, :, :].reshape(d,d,d,d)[:,:,:,:]) if False else None
    amp=np.zeros((d,d),complex)
    for y in range(d): amp+=state[y,:,:,y]/np.sqrt(d)
    p_succ=np.sum(np.abs(amp)**2)
    A=sum(reduce(np.kron,[proj(bits(o)[k],(gx(o)>>k)&1,al[k]) for k in range(n)][::-1]) for o in range(d))
    W=np.real(np.conj(psi)@A@psi)
    return p_succ*d*d, W
for n in (1,2,3):
    for _ in range(3):
        a,b=run(n); print("n=%d  d^2*p_succ=%.12f   W=%.12f   diff %.1e"%(n,a,b,abs(a-b)))
