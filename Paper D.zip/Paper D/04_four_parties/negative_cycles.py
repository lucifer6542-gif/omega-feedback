"""Proposition 30 and Theorem 32: negative cycles of the history digraph.
Counts the four-party classes (weight <= 3) whose history digraph has no negative cycle; for them det V' has
nonnegative coefficients by Proposition 30. Expected: 851 classes in total, 29 of them without a neutral party."""
import json, numpy as np, networkx as nx
from collections import Counter
exec(open('neutral4.py').read().split("stat=Counter()")[0])     # strings(), tabs(), the class list u
n=4; N=16
def negative_cycle(G):
    xm=[sum(((G[k]>>o)&1)<<k for k in range(n)) for o in range(N)]
    D=nx.DiGraph(); D.add_nodes_from(range(N))
    D.add_edges_from((o,q) for o in range(N) for q in range(N) if q!=o and ((q^o)&~xm[o])==0)
    for cyc in nx.simple_cycles(D):
        down=sum(bin(a&~b).count('1') for a,b in zip(cyc,cyc[1:]+cyc[:1]))
        if (len(cyc)-1+down)%2: return True
    return False
stat=Counter()
for key in u:
    G=tabs(key); S=strings(G)
    neutral=any(not any(V>>k&1 for U,V,c in S) for k in range(n))
    stat[('neutral party' if neutral else 'no neutral party','no negative cycle' if not negative_cycle(G) else 'negative cycle')]+=1
for k,v in sorted(stat.items()): print(k,v)
print("total without a negative cycle:",sum(v for k,v in stat.items() if k[1]=='no negative cycle'))
