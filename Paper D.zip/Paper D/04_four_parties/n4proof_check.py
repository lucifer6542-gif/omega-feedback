"""Symbolic check of the hand certificates for the non-affine mixed-sign det factors at n=4."""
import pickle, sympy as sp
u=sp.symbols('u0:4'); u0,u1,u2,u3=u
H=pickle.load(open("hardpolys.pkl","rb"))
F={k:sp.expand(sp.sympify(v[0])) for k,v in H.items()}
ok=lambda e: sp.expand(e)==0
def allpos(e): e=sp.expand(e); return e==0 or min(sp.Poly(e,*u).coeffs())>=0
res={}
# (18,1)
res[(18,1)]=ok(F[(18,1)]-(1+u0+u1+u2+u3)**2-u0*u2*u3*(u1-2)**2)
# greedy: square + positive
Q=u1*u2*u3-u2-u3-1
res[(87,3)]=allpos(F[(87,3)]-u0**2*Q**2)
res[(127,7)]=allpos(F[(127,7)]-u0**2*(u1+1)*(u3+1)*(u1*u2*u3-u2-1)**2)
res[(45,2)]=allpos(F[(45,2)]-u0**2*(u1+1)*(u2*u3-1)**2)
res[(67,1)]=allpos(F[(67,1)]-u0**2*u1**2*(u2*u3-1)**2)
res[(58,7)]=allpos(F[(58,7)]-(u0*Q-(u3+1)*(u2+u3))**2)
# quadratic in u1 with positive leading coeff and discriminant
for sig in [(88,6),(138,4),(145,10),(116,12),(58,7),(87,3),(18,1)]:
    cp=sp.Poly(F[sig],u1); assert cp.degree()==2
    a,b,c=[cp.coeff_monomial(u1**j) for j in (2,1,0)]
    res[(sig,'disc-u1')]=allpos(a) and allpos(sp.expand(4*a*c-b**2)) and sp.Poly(sp.expand(4*a*c-b**2),*u).coeff_monomial(u0*u2*u3)!=0 or allpos(a) and allpos(sp.expand(4*a*c-b**2))
# (173,30): two representations
f=F[(173,30)]; cp=sp.Poly(f,u0); a,b,c=[cp.coeff_monomial(u0**j) for j in (2,1,0)]
C=sp.factor_list(c)[1][0][0]; A=(u1+1)*Q
R1=u1*u2*u3-u1*u2-u1-u2-u3-1; R2=u1*u2*u3+u1*u2+u1-u2-u3-1
res[(173,30)]=ok(f-(A*u0+C)**2-4*u0*(u1+1)*(u2+1)*(u3+1)*R1**2) and ok(f-(A*u0-C)**2-4*u0*u2*u3*(u1+1)**2*R2**2) \
   and ok(C-((u1*(u2*u3+u2+1)+1+u2+u3)**2-4*u1*u2*u3**2))
for k,v in res.items(): print(k,v)
