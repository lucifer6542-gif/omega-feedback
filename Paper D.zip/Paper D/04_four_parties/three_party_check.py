"""Theorem 31 (three parties, by hand): computational cross-check.
Counts the 3-party feedbacks with a neutral party (expected 3840 of 4096), splits the remaining 256 into
relabelings of the NOR loop (64) and of the mixed loop (192), and checks that det V' always contains the
factor 1 + t0^2 + t1^2 + t2^2 times powers of (1 + tk^2)."""
import numpy as np, itertools, sympy as sp
n=3; N=8; others=[[1,2],[0,2],[0,1]]
chi=np.array([[(-1)**bin(o&T).count('1') for o in range(N)] for T in range(N)])
def strings(g):
    out=[]
    for U in range(1,N):
        if bin(U).count('1')<2: continue
        f=np.array([(-1)**(sum(g[k][o] for k in range(n) if U>>k&1)%2) for o in range(N)])
        fh=chi@f/N
        out+=[(U,T&~U) for T in range(N) if abs(fh[T])>1e-12 and (T&U)==U]
    return out
allg=[]
for fs in itertools.product(range(16),repeat=3):
    allg.append([[ (fs[k]>>(((o>>others[k][0])&1)|(((o>>others[k][1])&1)<<1)))&1 for o in range(N)] for k in range(3)])
core=[g for g in allg if not [k for k in range(3) if not any(V>>k&1 for U,V in strings(g))]]
print("three-party feedbacks:",len(allg)," with a neutral party:",len(allg)-len(core)," without:",len(core))
def key(g): return tuple(tuple(r) for r in g)
def transform(g,perm,of,inf):
    h=[[0]*8 for _ in range(3)]
    for o in range(8):
        old=sum((((o>>perm[k])&1)^((of>>perm[k])&1))<<k for k in range(3))
        for k in range(3): h[perm[k]][o]=g[k][old]^((inf>>perm[k])&1)
    return h
NOR=[[1,1,0,0,0,0,0,0],[1,0,1,0,0,0,0,0],[1,0,0,0,1,0,0,0]]
MIX=[[1,1,0,0,0,0,0,0],[1,0,1,0,0,0,0,0],[0,1,1,0,0,1,1,0]]
for name,rep in (("NOR loop",NOR),("mixed loop",MIX)):
    orb={key(transform(rep,p,a,b)) for p in itertools.permutations(range(3)) for a in range(8) for b in range(8)}
    print(name,"orbit size",len(orb)," contained in the 256:",orb<= {key(g) for g in core})
t=sp.symbols('t0:3')
def detVp(g):
    rows=[]
    for o in range(8):
        v=[sp.Integer(1)]
        for k in range(3):
            ok=(o>>k)&1
            e=([1,0] if ok==0 else [0,1]) if g[k][o]==0 else ([1,t[k]] if ok==0 else [-t[k],1])
            v=[a*b for a in v for b in e]
        rows.append(v)
    return sp.factor(sp.Matrix(rows).det(method='bareiss'))
for name,rep in (("NOR loop",NOR),("mixed loop",MIX)):
    print(name,"det V' =",detVp(rep))
