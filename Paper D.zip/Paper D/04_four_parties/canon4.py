import numpy as np, itertools, time
from enum4 import tabs
n=4; N=16
sols=np.load("enum4_sols.npy").astype(np.int64)
T16=[np.array([sum(int(tabs[k][f,o])<<o for o in range(N)) for f in range(256)],dtype=np.int64) for k in range(n)]
G=np.stack([T16[k][sols[:,k]] for k in range(n)],1)   # (S,4) 16-bit tables
allv=np.arange(65536,dtype=np.int64)
def dep(Gk,j):  # does table depend on bit j
    sh=1<<j
    mask=sum(1<<o for o in range(N) if not (o>>j)&1)
    lo=Gk & mask; hi=(Gk>>sh) & mask
    return lo!=hi
nonconst=np.all((G!=0)&(G!=0xFFFF),1)
read=np.ones(len(G),bool)
for j in range(n):
    r=np.zeros(len(G),bool)
    for k in range(n):
        if k!=j: r|=dep(G[:,k],j)
    read&=r
core=nonconst&read
print("total",len(G),"cores",core.sum())
G=G[core]
def perm_lookup(src):  # src[o'] = o ; result bit o' = bit src[o'] of input
    L=np.zeros(65536,dtype=np.int64)
    for op in range(N): L|=((allv>>src[op])&1)<<op
    return L
t0=time.time()
best=None
for pi in itertools.permutations(range(n)):
    for e in range(N):
        src=[]
        for op in range(N):
            o=sum(((op>>pi[j])&1)<<j for j in range(n))
            src.append(o^e)
        L=perm_lookup(src)
        H=L[G]                       # tables of old party k, in new coordinates
        H=np.where(H&1,H^0xFFFF,H)   # input-flip gauge: g(0)=0
        newH=np.empty_like(H)
        for k in range(n): newH[:,pi[k]]=H[:,k]
        key=(newH[:,0]<<48)|(newH[:,1]<<32)|(newH[:,2]<<16)|newH[:,3]
        best=key if best is None else np.minimum(best,key)
print("canon time",round(time.time()-t0,1))
u,inv,cnt=np.unique(best,return_inverse=True,return_counts=True)
print("classes",len(u))
np.save("enum4_classes.npy",u)
