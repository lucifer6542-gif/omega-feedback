import numpy as np, itertools, time
n=4; N=16
par=np.array([1-2*(bin(o).count('1')&1) for o in range(N)])
# tables for party k: functions of the 3 other bits
tabs=[]
for k in range(n):
    others=[j for j in range(n) if j!=k]
    T=np.zeros((256,N),dtype=np.int8)
    for f in range(256):
        for o in range(N):
            idx=sum(((o>>j)&1)<<i for i,j in enumerate(others))
            T[f,o]=(f>>idx)&1
    tabs.append(T)
F=[1-2*t.astype(np.int32) for t in tabs]  # +-1
if __name__=='__main__':
  t0=time.time()
  sols=[]
  cnt=0
  for a in range(256):
      f0=F[0][a]
      ok1=(F[1]*f0*par).sum(1)==0
      for b in np.nonzero(ok1)[0]:
          f01=f0*F[1][b]
          c_ok=((F[2]*f0*par).sum(1)==0)&((F[2]*F[1][b]*par).sum(1)==0)&((F[2]*f01*par).sum(1)==0)
          cs=np.nonzero(c_ok)[0]
          if len(cs)==0: continue
          F2=F[2][cs]                     # (m,16)
          # for g3: conditions with U containing 3: {0,3},{1,3},{2,3},{0,1,3},{0,2,3},{1,2,3},{0,1,2,3}
          base3=((F[3]*f0*par).sum(1)==0)&((F[3]*F[1][b]*par).sum(1)==0)&((F[3]*f01*par).sum(1)==0)
          d0=np.nonzero(base3)[0]
          if len(d0)==0: continue
          F3=F[3][d0]
          # remaining conds depend on c: {2,3},{0,2,3},{1,2,3},{0,1,2,3}
          P=par
          M1=(F2*P)@F3.T; M2=(F2*f0*P)@F3.T; M3=(F2*F[1][b]*P)@F3.T; M4=(F2*f01*P)@F3.T
          ok=(M1==0)&(M2==0)&(M3==0)&(M4==0)
          ii,jj=np.nonzero(ok)
          for i,j in zip(ii,jj): sols.append((a,int(b),int(cs[i]),int(d0[j])))
  print("solutions",len(sols),"time",round(time.time()-t0,1))
  np.save("enum4_sols.npy",np.array(sols,dtype=np.int16))
