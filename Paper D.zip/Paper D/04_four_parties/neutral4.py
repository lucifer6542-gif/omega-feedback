import numpy as np, json, itertools
from collections import Counter
n=4; N=16
u=np.load("enum4_classes.npy"); scan={int(r[0]):r for r in json.load(open("scan4.json"))}
chi=np.array([[(-1)**bin(o&T).count('1') for o in range(N)] for T in range(N)])
def tabs(key):
    key=int(key); return [((key>>s)&0xFFFF) for s in (48,32,16,0)]
def strings(Gt):
    g=[[ (Gt[k]>>o)&1 for o in range(N)] for k in range(n)]
    out=[]
    for U in range(1,N):
        if bin(U).count('1')<2: continue
        f=np.array([(-1)**(sum(g[k][o] for k in range(n) if U>>k&1)%2) for o in range(N)])
        fh=chi@f/N
        for T in range(N):
            if abs(fh[T])>1e-12 and (T&U)==U:
                out.append((U,T&~U,fh[T]))   # X on U, Z on V=T\U
    return out
stat=Counter(); noneutral=[]
for key in u:
    Gt=tabs(key); S=strings(Gt)
    wt=max(bin(U|V).count('1') for U,V,c in S) if S else 0
    neutral=[k for k in range(n) if not any(V>>k&1 for U,V,c in S)]
    r=scan[int(key)]; pos=(r[3]==0)
    stat[(len(neutral)>0, pos)]+=1
    if not neutral: noneutral.append(int(key))
print("(has neutral, all-positive coeffs): count")
for k,v in sorted(stat.items()): print(k,v)
json.dump(noneutral,open("noneutral.json","w"))
print("classes without neutral party:",len(noneutral))
