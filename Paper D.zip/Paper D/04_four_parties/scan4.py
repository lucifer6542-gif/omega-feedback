import numpy as np, time, json, sys
from fdet import signs
u=np.load("enum4_classes.npy")
res=[]; t0=time.time()
for i,key in enumerate(u):
    key=int(key); Gt=[(key>>48)&0xFFFF,(key>>32)&0xFFFF,(key>>16)&0xFFFF,key&0xFFFF]
    L,p,m,d=signs(Gt)
    res.append((key,L,p,m))
    if i%2000==0: print(i,round(time.time()-t0,1),flush=True)
json.dump(res,open("scan4.json","w"))
mixed=[r for r in res if r[2]>0 and r[3]>0]; neg=[r for r in res if r[2]==0]
print("classes",len(res),"all-positive",sum(r[3]==0 for r in res),"all-negative",len(neg),"mixed",len(mixed))
