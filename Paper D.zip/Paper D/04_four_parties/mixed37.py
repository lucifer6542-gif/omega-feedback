import json, numpy as np
from scipy.optimize import minimize
from lvl import frame_A
res=json.load(open("scan4.json")); mixed=[r for r in res if r[2]>0 and r[3]>0]
n=4; N=16
H=np.array([[1-2*(bin(o&T).count('1')&1) for T in range(N)] for o in range(N)])/N
rng=np.random.default_rng(3); eps=0.01
def tables(key): return [(key>>48)&0xFFFF,(key>>32)&0xFFFF,(key>>16)&0xFFFF,key&0xFFFF]
def garr(Gt): return [np.array([(G>>o)&1 for o in range(N)]) for G in Gt]
def is_aff(g): return all(np.abs((1-2*gk)@H).max()>1-1e-9 for gk in g)
out=[]
for key,L,p,m in mixed:
    g=garr(tables(key)); aff=is_aff(g)
    lam=lambda a: np.linalg.eigvalsh(frame_A(g,np.clip(a,eps,np.pi-eps),n))[0]
    best=9;ba=None
    for r in range(25):
        o=minimize(lam,rng.uniform(eps,np.pi-eps,n),method="Nelder-Mead",options={"maxiter":800,"fatol":1e-12,"xatol":1e-7})
        if o.fun<best: best=o.fun; ba=np.clip(o.x,eps,np.pi-eps)
    edge=min(np.min(ba-eps),np.min(np.pi-eps-ba))
    out.append((key,aff,m,L,best,edge))
    print("aff" if aff else "NON", f"neg {m}/{L}", f"lam {best:.2e}", f"edge {edge:.3f}", np.round(ba,3), flush=True)
json.dump([[int(a),bool(b),c,d,float(e),float(f)] for a,b,c,d,e,f in out],open("mixed37.json","w"))
