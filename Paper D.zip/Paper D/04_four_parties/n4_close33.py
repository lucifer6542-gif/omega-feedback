"""Theorem (four parties), step 4: close all 33 non-affine mixed-sign classes.
Each mixed-sign factor of det V' (u_k = tan^2(alpha_k/2)) is certified by one of:
  (a) quadratic in one variable with nonnegative leading coefficient and nonnegative discriminant 4ac-b^2,
  (b) square + polynomial with nonnegative coefficients,
  (c) two representations (A u0 +- C)^2 + positive terms, with C > 0 by AM-GM.
Certificates (b)/(c) that the greedy search misses are checked explicitly on the polynomial itself."""
import json, sympy as sp
from fdet import detG
u=sp.symbols('u0:4'); t=sp.symbols('t0:4')
def allpos(e): e=sp.expand(e); return e==0 or min(sp.Poly(e,*u).coeffs())>=0
res=json.load(open("mixed37.json")); stats={}
for key,aff,m,L,lam,edge in res:
    if aff: continue
    Gt=[(key>>48)&0xFFFF,(key>>32)&0xFFFF,(key>>16)&0xFFFF,key&0xFFFF]
    d=detG(Gt); c,facs=d.factor()
    for f,e in facs:
        cs=[int(x) for x in f.coeffs()]
        if not(min(cs)<0<max(cs)): continue
        P=sp.expand(sp.sympify(str(f).replace("^","**"),locals={'t%d'%i:t[i] for i in range(4)}).subs({t[i]:sp.sqrt(u[i]) for i in range(4)}))
        how=None
        for v in range(4):
            cp=sp.Poly(P,u[v])
            if cp.degree()!=2: continue
            a,b,cc=[cp.coeff_monomial(u[v]**j) for j in (2,1,0)]
            if allpos(a) and allpos(4*a*cc-b**2): how=f"disc-u{v}"; break
        if how is None:
            # two-representation test in any var with a=A^2, c=C^2
            for v in range(4):
                cp=sp.Poly(P,u[v])
                if cp.degree()!=2: continue
                a,b,cc=[cp.coeff_monomial(u[v]**j) for j in (2,1,0)]
                fa=sp.factor_list(a); fc=sp.factor_list(cc)
                if all(e%2==0 for _,e in fa[1]) and all(e%2==0 for _,e in fc[1]) and fa[0]>0 and fc[0]>0:
                    A=sp.sqrt(fa[0])*sp.prod([q**(e//2) for q,e in fa[1]]); C=sp.sqrt(fc[0])*sp.prod([q**(e//2) for q,e in fc[1]])
                    if allpos(b-2*A*C) and allpos(b+2*A*C): how=f"two-forms-u{v}"; break
        if how is None:
            R=P
            for it in range(6):
                if allpos(R): break
                done=False
                for v in range(4):
                    cp=sp.Poly(R,u[v])
                    for (j,),cf in zip(cp.monoms(),cp.coeffs()):
                        if allpos(cf): continue
                        fl=sp.factor_list(cf); sq=sp.Integer(1); oth=sp.Integer(fl[0])
                        for bb,ee in fl[1]: sq*=bb**(ee//2); oth*=bb**(ee%2)
                        if sq==1 or not allpos(oth): continue
                        R=sp.expand(R-u[v]**j*oth*sq**2); done=True; break
                    if done: break
                if not done: break
            how="square+positive" if allpos(R) else "UNRESOLVED"
        if how=="UNRESOLVED":
            u0,u1,u2,u3=u
            # explicit (b): f - u_a^2 u_b^2 (u_c u_d - 1)^2 >= 0 coefficientwise, any labeling
            import itertools
            for p in itertools.permutations(range(4)):
                if allpos(P-u[p[0]]**2*u[p[1]]**2*(u[p[2]]*u[p[3]]-1)**2): how="square+positive (explicit)"; break
        if how=="UNRESOLVED":
            # explicit (c): two representations, as in the paper's (173,30) identity
            ok=lambda e: sp.expand(e)==0
            for p in itertools.permutations(range(4)):
                v0,v1,v2,v3=[u[i] for i in p]
                Q=v1*v2*v3-v2-v3-1; A=(v1+1)*Q
                C=(v1*(v2*v3+v2+1)+1+v2+v3)**2-4*v1*v2*v3**2
                R1=v1*v2*v3-v1*v2-v1-v2-v3-1; R2=v1*v2*v3+v1*v2+v1-v2-v3-1
                if ok(P-(A*v0+C)**2-4*v0*(v1+1)*(v2+1)*(v3+1)*R1**2) and ok(P-(A*v0-C)**2-4*v0*v2*v3*(v1+1)**2*R2**2):
                    how="two-representations"; break
        stats[how]=stats.get(how,0)+1
        if how=="UNRESOLVED": print("unresolved class",hex(key&((1<<64)-1)),len(cs),sum(x<0 for x in cs))
print(stats); print("total classes:",sum(stats.values()),"  unresolved:",stats.get("UNRESOLVED",0))
