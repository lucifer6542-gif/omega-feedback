"""Machine check of the hand proof of Lemma 12 (paper D, Section 3.2), Steps 5-6.
Rows are restricted to the configuration's parties; arcs v->u iff u in m[v]."""
import itertools
def good(m,U): return all(sum(1 for v in U if u in m[v])%2==1 for u in U)
def w(m,U):
    s=set()
    for v in U: s^=m[v]
    return s
def struct(m,digons):
    for i in range(len(m)): assert i not in m[i]
    for (i,j,t) in digons:
        assert j in m[i] and i in m[j] and (m[i]^m[j])=={i,j,t}
# Step 5: P5, tau=(2,3,4,tau_d)
for td,U in [(0,(0,3,4)),(1,(1,3,4))]:
    m=[{1},{0,2},{0,1,3},{0,1,2,4},{1,2,3} if td==0 else {0,2,3}]
    struct(m,[(0,1,2),(1,2,3),(2,3,4),(3,4,td)])
    assert good(m,U) and len(w(m,U))>=4
    # uniqueness of m0 on V'={0..4}
    sols=[]
    for b in range(32):
        m0={x for x in range(5) if b>>x&1}
        m1=m0^{0,1,2}; m2=m1^{1,2,3}; m3=m2^{2,3,4}; m4=m3^{3,4,td}
        mm=[m0,m1,m2,m3,m4]
        try: struct(mm,[(0,1,2),(1,2,3),(2,3,4),(3,4,td)]); sols.append(mm)
        except AssertionError: pass
    assert len(sols)==1 and sols[0]==m
    print("P5 tau_d=%d: unique rows, good set %s, |w|=%d"%(td,U,len(w(m,U))))
# Step 6: P4+K2, tau(a)=2,tau(b)=3,tau(c)=4,tau(d)=1
n_cases=0
for F in [set(),{4},{5},{4,5}]:
    for gb in range(16):
        G={x for x in range(4) if gb>>x&1}
        m=[{1}|F,{0,2}|F,{0,1,3}|F,{0,1,2}|(F^{4}),{5}|G,{4}|(G^{1})]
        struct(m,[(0,1,2),(1,2,3),(2,3,4),(4,5,1)])
        viol=[U for r in (2,3,4,5,6) for U in itertools.combinations(range(6),r) if good(m,U) and len(w(m,U))>=4]
        assert viol, (F,G)
        n_cases+=1
        if not F or not (G&{2,3}): continue   # excluded by (L1); still violated above
        # the specific witnesses used in the text
        if F=={4}: assert G=={3} or any(len(U)==2 and 4 in U for U in viol)
        if F=={4} and G=={3}: assert (0,3,4) in viol
        if F=={5}: assert G=={1,3} and (3,5) in viol or any(len(U)==2 and 5 in U and U[0]<3 for U in viol)
print("P4+K2: all %d completions violate weight<=3"%n_cases)
