import itertools, networkx as nx
# canonical shapes: 4 edges, max degree 2, acyclic (path forests), on labelled vertices
shapes={"P5":[(0,1),(1,2),(2,3),(3,4)],"P4+K2":[(0,1),(1,2),(2,3),(4,5)],"P3+P3":[(0,1),(1,2),(3,4),(4,5)],
        "P3+2K2":[(0,1),(1,2),(3,4),(5,6)],"4K2":[(0,1),(2,3),(4,5),(6,7)]}
for name,E in shapes.items():
    V=sorted(set(v for e in E for v in e)); extra=list(range(10,14))
    sols=[]
    for T in itertools.product(V+extra,repeat=4):
        if len(set(T))<4 or any(T[i] in E[i] for i in range(4)): continue
        ok=True
        for a,b in itertools.combinations(range(4),2):
            ea,eb=set(E[a]),set(E[b])
            sh=ea&eb
            if sh:   # adjacent: arc must be via far endpoint
                fa=(eb-sh).pop(); fb=(ea-sh).pop()
                if not (T[a]==fa or T[b]==fb): ok=False;break
            else:
                if not (T[a] in eb or T[b] in ea): ok=False;break
        if ok: sols.append(T)
    # dedupe outside-vertex labels
    canon=set()
    for T in sols:
        m={}; c=[]
        for t in T:
            if t>=10: m.setdefault(t,10+len(m)); c.append(m[t])
            else: c.append(t)
        canon.add(tuple(c))
    print(name,"survivors:",len(canon),sorted(canon)[:12])
