import sys, itertools, time
from pysat.solvers import Cadical153
n=int(sys.argv[1]); need=int(sys.argv[2])   # require parties 0..need-1 to be Z-targets
cnt=[0]
def nv(): cnt[0]+=1; return cnt[0]
M={(i,j):nv() for i in range(n) for j in range(n) if i!=j}
cl=[]; q={}
def xor_def(z,a,b): cl.extend([[-z,a,b],[-z,-a,-b],[z,-a,b],[z,a,-b]])
for u in range(n):
    for S in range(1,1<<n):
        if S>>u&1: continue
        low=S&-S; i=low.bit_length()-1; rest=S^low
        if rest==0: q[(u,S)]=M[(i,u)]
        else: z=nv(); xor_def(z,q[(u,rest)],M[(i,u)]); q[(u,S)]=z
good={}
for U in range(1,1<<n):
    mem=[u for u in range(n) if U>>u&1]; k=len(mem)
    if k<2: continue
    conds=[q[(u,U^(1<<u))] for u in mem]
    notall=[-c for c in conds]
    outs=[v for v in range(n) if not U>>v&1]
    if k>=4: cl.append(notall)
    elif k==3:
        for v in outs: cl.append(notall+[-q[(v,U)]])
    elif k==2:
        for a,b in itertools.combinations(outs,2): cl.append(notall+[-q[(a,U)],-q[(b,U)]])
        gU=nv(); good[U]=gU
        for c in conds: cl.append([-gU,c])
        cl.append([gU]+notall)
# target constraints
for v in range(need):
    lits=[]
    for U,gU in good.items():
        if U>>v&1: continue
        y=nv(); cl.append([-y,gU]); cl.append([-y,q[(v,U)]]); lits.append(y)
    cl.append(lits)
t=time.time(); s=Cadical153(bootstrap_with=cl); r=s.solve()
print("n",n,"targets required on",need,"parties:","SAT" if r else "UNSAT","%.1fs"%(time.time()-t),flush=True)
if r:
    m=set(x for x in s.get_model() if x>0)
    print([sum((1<<j) for j in range(n) if j!=i and M[(i,j)] in m) for i in range(n)])
