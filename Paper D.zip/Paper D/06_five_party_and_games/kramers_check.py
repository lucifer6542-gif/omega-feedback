"""Remark 35: the spectrum of A_g is fourfold degenerate at every angle (Kramers-type argument).

1. Symplectic part (exact, no angles): expand H = A_g - I in the rotated Pauli basis
   {I, Xt_k, Zt_k} (Xt_k = s_k Z - c_k X, Zt_k = c_k Z + s_k X, s_k = sin(alpha_k/2), c_k = cos(alpha_k/2)).
   The support of the expansion does not depend on the angles. List the strings and check that each
   one commutes with S = Y0 Y3 Y4 and with T = Zt1 Zt2 Y3 Zt4 (per party, two single-qubit Paulis from
   {Xt, Zt, Y} commute iff they are equal or one is the identity), and that S and T anticommute.
2. Numerical part: at random angles, [A_g, S] = [A_g, T] = 0, {S, T} = 0, S and T purely imaginary,
   and every eigenvalue multiplicity of A_g is divisible by four.
Expected: 11 strings, all commuting with S and T; S, T anticommute; multiplicities in {4, 8, ...} (exactly 4 at the random angles below).
"""
import json, itertools, numpy as np

tabs = json.loads(open('cand1.jsonl').readline()); n = len(tabs); N = 1 << n
I2 = np.eye(2); Z = np.diag([1., -1]); X = np.array([[0, 1.], [1, 0]]); Y = np.array([[0, -1j], [1j, 0]])

def kron(ops):
    M = np.array([[1.]])
    for a in ops: M = np.kron(M, a)          # party 0 most significant
    return M

def A_direct(al):
    A = np.zeros((N, N))
    for o in range(N):
        ops = []
        for k in range(n):
            x = tabs[k][o]; b = (o >> k) & 1
            Ax = Z if x == 0 else np.cos(al[k]) * Z + np.sin(al[k]) * X
            ops.append((I2 + (-1) ** b * Ax) / 2)
        A += kron(ops)
    return A

def rotated(al):
    s, c = np.sin(al / 2), np.cos(al / 2)
    return [s[k] * Z - c[k] * X for k in range(n)], [c[k] * Z + s[k] * X for k in range(n)]

# ---- 1. support of the Pauli expansion and symplectic commutation ----
rng = np.random.default_rng(7)
al = rng.uniform(0.3, np.pi - 0.3, n)
Xt, Zt = rotated(al)
H = A_direct(al) - np.eye(N)
names = {0: 'I', 1: 'Xt', 2: 'Zt'}
strings = []
for lab in itertools.product(range(3), repeat=n):
    P = kron([[I2, Xt[k], Zt[k]][lab[k]] for k in range(n)])
    if abs(np.trace(P @ H)) / N > 1e-12: strings.append(lab)
# same support at a second random point (support is angle independent)
al2 = rng.uniform(0.3, np.pi - 0.3, n); Xt2, Zt2 = rotated(al2); H2 = A_direct(al2) - np.eye(N)
strings2 = [lab for lab in itertools.product(range(3), repeat=n)
            if abs(np.trace(kron([[I2, Xt2[k], Zt2[k]][lab[k]] for k in range(n)]) @ H2)) / N > 1e-12]
assert strings == strings2

S_lab = ('Y', 'I', 'I', 'Y', 'Y')        # S = Y0 Y3 Y4
T_lab = ('I', 'Zt', 'Zt', 'Y', 'Zt')     # T = Zt1 Zt2 Y3 Zt4

def anticommute_count(a, b):
    return sum(1 for p, q in zip(a, b) if p != 'I' and q != 'I' and p != q)

print("Pauli strings of g:", len(strings))
ok = True
for lab in strings:
    w = tuple(names[l] for l in lab)
    cs, ct = anticommute_count(w, S_lab) % 2, anticommute_count(w, T_lab) % 2
    ok &= (cs == 0 and ct == 0)
    print("  ", " ".join(f"{p:>2}" for p in w), "  [.,S]=0" if cs == 0 else "  anticommutes with S",
          "  [.,T]=0" if ct == 0 else "  anticommutes with T")
print("all strings commute with S and T:", ok)
print("S and T anticommute:", anticommute_count(S_lab, T_lab) % 2 == 1)

# ---- 2. numerical check at random angles ----
for trial in range(5):
    al = rng.uniform(0.05, np.pi - 0.05, n)
    _, Zt = rotated(al)
    A = A_direct(al)
    S = kron([Y, I2, I2, Y, Y]); T = kron([I2, Zt[1], Zt[2], Y, Zt[4]])
    comm = max(np.abs(A @ S - S @ A).max(), np.abs(A @ T - T @ A).max())
    anti = np.abs(S @ T + T @ S).max()
    imag = max(np.abs(S.real).max(), np.abs(T.real).max())
    w = np.linalg.eigvalsh(A)
    _, mult = np.unique(np.round(w, 7), return_counts=True)
    print(f"alpha={np.round(al, 3)}  |[A,S]|,|[A,T]|={comm:.1e}  |{{S,T}}|={anti:.1e}  "
          f"real part of S,T={imag:.1e}  multiplicities={sorted(set(mult.tolist()))}")
al0 = np.array([2 * np.pi / 3, np.pi / 2, np.pi / 2, 2 * np.arctan(3), 2 * np.arctan(np.sqrt(5))])
w = np.linalg.eigvalsh(A_direct(al0))
print("at the paradox point: kernel dimension", int((np.abs(w) < 1e-9).sum()))
