import numpy as np, itertools, json
exec(open('intrinsic5.py').read().split("rng=np.random")[0])
# product vectors e_{o,x}: P(o|x)=|<e,psi>|^2 ; functional on kernel coordinates
def evec(o,x):
    v=np.array([1.])
    for k in range(n):
        b=(o>>k)&1; xx=(x>>k)&1
        if xx==0: u=np.array([1.,0.]) if b==0 else np.array([0.,1.])
        else:
            c,s=np.cos(al[k]/2),np.sin(al[k]/2); u=np.array([c,s]) if b==0 else np.array([-s,c])
        v=np.kron(v,u)
    return v
F=np.array([[ker.T@evec(o,x) for x in range(N)] for o in range(N)])   # (o,x,4)
norms=np.linalg.norm(F,axis=2)
print("identically zero entries:",int((norms<1e-10).sum()))
# group nonzero functionals by direction (up to sign)
dirs=[]; members=[]
for o in range(N):
    for x in range(N):
        if norms[o,x]<1e-10: continue
        d=F[o,x]/norms[o,x]
        for i,e in enumerate(dirs):
            if abs(abs(d@e)-1)<1e-9: members[i].append((o,x)); break
        else: dirs.append(d); members.append([(o,x)])
sizes=sorted([len(m) for m in members],reverse=True)
print("distinct directions:",len(dirs),"  largest groups:",sizes[:8])
# choose psi orthogonal to the 3 largest-group directions (and try other combos among top groups)
order=np.argsort([-len(m) for m in members])
best=(0,None)
top=order[:12]
for tri in itertools.combinations(top,3):
    Mx=np.array([dirs[i] for i in tri])
    u,s,vt=np.linalg.svd(Mx)
    if s[-1]<1e-8: continue
    c=vt[-1]
    nz=int((norms<1e-10).sum())+sum(len(members[i]) for i in range(len(dirs)) if abs(dirs[i]@c)<1e-9)
    if nz>best[0]: best=(nz,c)
print("max zero entries reachable with 3 constraints:",best[0])
np.save('psi_special.npy',ker@best[1])
