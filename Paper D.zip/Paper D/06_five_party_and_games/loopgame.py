"""Loop-avoidance game from the GHZ4 box: referee picks g in G0 and x uniformly; players win iff g(o) != x.
Quantum (GHZ4, sigma_x/sigma_y) wins with probability 1. Compute the classical maximum."""
import itertools
exec(open('ghz4_intrinsic.py').read().split("# Step 3")[0])
def g_of(gd,o):
    x=0
    for k in range(n): x=(x<<1)|gd[k][others(o,k)]
    return x
# quantum winning probability
pq=sum(sum(Pt[o][x] for o in range(N) if g_of(gd,o)!=x) for gd in G0 for x in range(N))/(len(G0)*N)
print("|G0| =",len(G0)," quantum winning probability:",round(pq,12))
fs=[lambda b:0,lambda b:1,lambda b:b,lambda b:1-b]
best=0; arg=None
for F in itertools.product(range(4),repeat=n):
    wins=0
    for x in range(N):
        o=0
        for k in range(n): o=(o<<1)|fs[F[k]](bit(x,k))
        wins+=sum(1 for gd in G0 if g_of(gd,o)!=x)
    if wins>best: best,arg=wins,F
tot=len(G0)*N
print("classical maximum: %d/%d = %.6f"%(best,tot,best/tot))
# also: per-g classical (each single loop alone) to show individual loops are classically winnable
for i,gd in enumerate(G0):
    b=max(sum(1 for x in range(N) if g_of(gd,(lambda x: int(''.join(str(fs[F[k]](bit(x,k))) for k in range(n)),2))(x))!=x) for F in itertools.product(range(4),repeat=n))
    print("  loop %d alone: classical max %d/16"%(i,b))
