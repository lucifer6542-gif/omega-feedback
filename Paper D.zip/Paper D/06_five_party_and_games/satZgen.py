"""SAT: does a general (non-affine) feedback of Pauli weight <= 3 exist on n parties
in which every party in TGT is a target (non-neutral)?
weight<=3  <=>  for all U (|U|>=2), all T ⊇ U with |T|>=4:  f_U^(T) = 0,
f_U(o) = (-1)^{xor_{u in U} g_u(o)}.  Party k is neutral iff f_{ij}^({i,j,k}) = 0 for all pairs {i,j} not containing k."""
import sys, itertools, time
from pysat.formula import CNF, IDPool
from pysat.card import CardEnc, EncType, ITotalizer
from pysat.solvers import Cadical153
n=int(sys.argv[1]); ntgt=int(sys.argv[2]) if len(sys.argv)>2 else n
N=1<<n; H=N//2
pool=IDPool(); cnf=CNF()
def G(k,o):  # g_k(o), independent of o_k
    r=tuple((o>>j)&1 for j in range(n) if j!=k)
    return pool.id(('g',k,r))
def xor2(a,b):
    y=pool.id(('x',a,b)) if a<b else pool.id(('x',b,a))
    cnf.extend([[-y,a,b],[-y,-a,-b],[y,-a,b],[y,a,-b]]); return y
Y={}
def Yv(U,o):  # literal for xor_{u in U} g_u(o)
    key=(U,o)
    if key in Y: return Y[key]
    us=[u for u in range(n) if U>>u&1]
    if len(us)==1: v=G(us[0],o)
    else:
        last=us[-1]; v=xor2(Yv(U&~(1<<last),o),G(last,o))
    Y[key]=v; return v
def lits(U,T):  # literal true iff h(o)=1 where h = xor_U g ⊕ <T,o>
    out=[]
    for o in range(N):
        y=Yv(U,o); c=bin(o&T).count('1')&1
        out.append(-y if c else y)
    return out
pc=lambda x: bin(x).count('1')
ncons=0
for U in range(N):
    if pc(U)<2: continue
    for T in range(N):
        if (T&U)==U and pc(T)>=4:
            cnf.extend(CardEnc.equals(lits(U,T),bound=H,vpool=pool,encoding=EncType.seqcounter).clauses); ncons+=1
# core conditions: no constant input, every output read by someone
CORE=int(sys.argv[3]) if len(sys.argv)>3 else 1
if CORE:
    for k in range(n):
        tab=[G(k,o) for o in range(N) if not (o>>k)&1]
        cnf.append(tab); cnf.append([-x for x in tab])
    for k in range(n):
        reads=[]
        for j in range(n):
            if j==k: continue
            for o in range(N):
                if (o>>k)&1==0: reads.append(xor2(G(j,o),G(j,o|(1<<k))))
        cnf.append(reads)
# target conditions
tg=list(range(ntgt))
for k in tg:
    nbs=[]
    for i,j in itertools.combinations([x for x in range(n) if x!=k],2):
        L=lits((1<<i)|(1<<j),(1<<i)|(1<<j)|(1<<k))
        t1=ITotalizer(L,ubound=H,top_id=pool.top); pool.top=t1.top_id
        t2=ITotalizer([-l for l in L],ubound=H,top_id=pool.top); pool.top=t2.top_id
        cnf.extend(t1.cnf.clauses); cnf.extend(t2.cnf.clauses)
        nb=pool.id(('nb',k,i,j)); nbs.append(nb)
        cnf.append([-nb,-t1.rhs[H-1],-t2.rhs[H-1]])   # sum<=H-1 or #false<=H-1
    cnf.append(nbs)
t=time.time()
with Cadical153(bootstrap_with=cnf.clauses) as s:
    r=s.solve()
    print("n=%d targets on %d parties: %s  (%d weight constraints, %d vars, %.1fs)"%(n,ntgt,"SAT" if r else "UNSAT",ncons,pool.top,time.time()-t))
    if r:
        m=set(x for x in s.get_model() if x>0)
        for k in range(n):
            tab=[1 if G(k,o) in m else 0 for o in range(N)]
            print(" g_%d:"%k,''.join(map(str,tab)))
