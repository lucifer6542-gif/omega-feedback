"""Is the quantum box from the 5-party weight-3 counterexample profile intrinsic?
Box: kernel state psi of A_g at alpha=(2pi/3, pi/2, pi/2, 2atan3, 2atan sqrt5); party k measures Z (x=0) or cos a Z + sin a X (x=1)."""
import json, numpy as np, itertools, sys
from pysat.solvers import Cadical153
tabs=json.loads(open('cand1.jsonl').readline()); n=5; N=32
al=np.array([2*np.pi/3,np.pi/2,np.pi/2,2*np.arctan(3),2*np.arctan(np.sqrt(5))])
I2=np.eye(2); Z=np.diag([1.,-1]); X=np.array([[0,1.],[1,0]])
def proj(k,b,x):
    A=Z if x==0 else np.cos(al[k])*Z+np.sin(al[k])*X
    return (I2+(-1)**b*A)/2
def bigproj(o,x):   # party 0 most significant in kron; bit k of o/x belongs to party k
    M=np.array([[1.]])
    for k in range(n): M=np.kron(M,proj(k,(o>>k)&1,(x>>k)&1))
    return M
A=sum(bigproj(o,sum(tabs[k][o]<<k for k in range(n))) for o in range(N))
w,v=np.linalg.eigh(A); ker=v[:,w<1e-9]; print("kernel dim:",ker.shape[1])
rng=np.random.default_rng(int(sys.argv[1]) if len(sys.argv)>1 else 0)
psi=ker@rng.normal(size=ker.shape[1]); psi/=np.linalg.norm(psi)
Pt=np.array([[psi@bigproj(o,x)@psi for x in range(N)] for o in range(N)])
assert np.allclose(Pt.sum(0),1)
gx=lambda o: sum(tabs[k][o]<<k for k in range(n))
print("W(P; g) for the defining feedback:",sum(Pt[o][gx(o)] for o in range(N)))
zero=Pt<1e-10
print("zero entries of P(o|x):",int(zero.sum()),"of",N*N)
# enumerate G0: all general feedbacks with W=0
def others(o,k): return tuple((o>>j)&1 for j in range(n) if j!=k)
var={}
def V(k,r):
    if (k,r) not in var: var[(k,r)]=len(var)+1
    return var[(k,r)]
cls=[]
for o in range(N):
    for x in range(N):
        if not zero[o][x]:
            cls.append([(-V(k,others(o,k)) if (x>>k)&1 else V(k,others(o,k))) for k in range(n)])
G0=[]
with Cadical153(bootstrap_with=cls) as so:
    while so.solve() and len(G0)<100000:
        m=set(l for l in so.get_model() if l>0)
        G0.append({key:(1 if V(*key) in m else 0) for key in var})
        so.add_clause([-vv if vv in m else vv for vv in var.values()])
print("|G0| =",len(G0))
def g_of(gd,o): return sum(gd[(k,others(o,k))]<<k for k in range(n))
fs=[lambda b:0,lambda b:1,lambda b:b,lambda b:1-b]
best=0; wit=0
for F in itertools.product(range(4),repeat=n):
    wins=0
    for x in range(N):
        o=sum(fs[F[k]]((x>>k)&1)<<k for k in range(n))
        wins+=sum(1 for gd in G0 if g_of(gd,o)!=x)
    best=max(best,wins); wit+= wins==len(G0)*N
tot=len(G0)*N
print("classical max win: %d/%d = %.6f ; perfect classical strategies: %d"%(best,tot,best/tot,wit))
print("=> profile intrinsic" if wit==0 else "=> NOT profile intrinsic")
