import json, numpy as np, itertools
tabs=json.loads(open('cand1.jsonl').readline()); n=len(tabs); N=1<<n
I2=np.eye(2); Z=np.diag([1.,-1]); X=np.array([[0,1.],[1,0]])
def A_direct(al):
    A=np.zeros((N,N))
    for o in range(N):
        M=np.array([[1.]])
        for k in range(n):   # party 0 most significant in kron
            x=tabs[k][o]; b=(o>>k)&1
            Ax=Z if x==0 else np.cos(al[k])*Z+np.sin(al[k])*X
            M=np.kron(M,(I2+(-1)**b*Ax)/2)
        A+=M
    return A
rng=np.random.default_rng(1)
al=rng.uniform(0.3,np.pi-0.3,n)
A=A_direct(al); H=A-np.eye(N)
# rotated Paulis per party
basis=[]
for k in range(n):
    s,c=np.sin(al[k]/2),np.cos(al[k]/2)
    Xt=s*Z-c*X; Zt=c*Z+s*X; Yt=Zt@Xt  # (anti-hermitian*i) fine for support detection
    basis.append([I2,Xt,Zt,Yt])
maxw=0; nz=0
for lab in itertools.product(range(4),repeat=n):
    P=np.array([[1.]])
    for k in range(n): P=np.kron(P,basis[k][lab[k]])
    coef=np.trace(P.T@H)/N
    if abs(coef)>1e-12:
        nz+=1; maxw=max(maxw,sum(1 for l in lab if l!=0))
print("independent Pauli expansion: nonzero strings",nz," max weight",maxw)
zero=np.array([2.4799,1.5332,2.3965,2.6833,1.7785])
# refine zero then evaluate directly
from scipy.optimize import minimize
r=minimize(lambda a: np.linalg.eigvalsh(A_direct(a))[0],zero,method='Nelder-Mead',options={'maxiter':6000,'xatol':1e-13,'fatol':1e-17})
ev=np.linalg.eigvalsh(A_direct(r.x))
print("direct operator at refined zero alpha=",np.round(r.x,5)," lambda_min=%.2e  next=%.3f"%(ev[0],ev[1]))
