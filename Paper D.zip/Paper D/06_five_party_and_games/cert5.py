"""Exact certificate: det V'(t0, 1, 1, 3, t4) as a polynomial in (t0, t4) over Q, then t0 = sqrt(3)."""
import json, flint, sympy as sp, time
tabs=json.loads(open('cand1.jsonl').readline()); n=len(tabs); N=1<<n
def Vprime(t):
    cols=[]
    for o in range(N):
        v=[flint.fmpq(1)]
        for k in range(n):
            b=(o>>k)&1; x=tabs[k][o]
            if x==0: vk=[flint.fmpq(1),flint.fmpq(0)] if b==0 else [flint.fmpq(0),flint.fmpq(1)]
            else:    vk=[flint.fmpq(1),t[k]] if b==0 else [-t[k],flint.fmpq(1)]
            v=[a*bb for a in v for bb in vk]
        cols.append(v)
    return flint.fmpq_mat([[cols[j][i] for j in range(N)] for i in range(N)])
d0=sum(1 for o in range(N) if tabs[0][o]==1); d4=sum(1 for o in range(N) if tabs[4][o]==1)
print("degree bounds: t0 <=",d0,"  t4 <=",d4)
t=time.time()
S=list(range(-(d0//2),d0-(d0//2)+1)); T=list(range(-(d4//2),d4-(d4//2)+1))
vals={}
for s in S:
    for u in T:
        vals[(s,u)]=Vprime([flint.fmpq(s),flint.fmpq(1),flint.fmpq(1),flint.fmpq(3),flint.fmpq(u)]).det()
print("exact evaluations:",len(vals),"(%.1fs)"%(time.time()-t))
x,y=sp.symbols('s t4')
# bivariate Lagrange interpolation: first in t4 for each s, then in s
rows=[]
for s in S:
    pts=[(u,sp.Rational(int(vals[(s,u)].p),int(vals[(s,u)].q))) for u in T]
    rows.append(sp.Poly(sp.interpolate(pts,y),y))
deg_t4=max(r.degree() for r in rows)
F=0
for j in range(deg_t4+1):
    cj=[(s,r.coeff_monomial(y**j)) for s,r in zip(S,rows)]
    F+=sp.expand(sp.interpolate(cj,x))*y**j
F=sp.Poly(sp.expand(F),x,y)
# sanity: check F at an extra point not used in interpolation
chk=Vprime([flint.fmpq(7,3),flint.fmpq(1),flint.fmpq(1),flint.fmpq(3),flint.fmpq(5,2)]).det()
assert F.eval({x:sp.Rational(7,3),y:sp.Rational(5,2)})==sp.Rational(int(chk.p),int(chk.q)), "interpolation check failed"
print("F(s,t4) recovered exactly; degrees",F.degree(x),F.degree(y),"; off-grid check passed")
G=sp.expand(F.as_expr().subs(x,sp.sqrt(3)))
A=sp.Poly(sp.expand(G).coeff(sp.sqrt(3),0),y); B=sp.Poly(sp.expand(G).coeff(sp.sqrt(3),1),y)
assert sp.expand(A.as_expr()+sp.sqrt(3)*B.as_expr()-G)==0
print("G(t4) = A(t4) + sqrt(3) B(t4); deg A",A.degree(),"deg B",B.degree())
# a real root of G is a common root of ... use gcd over Q(sqrt3)
Gp=sp.Poly(G,y,extension=sp.sqrt(3))
fac=sp.factor_list(Gp.as_expr(),y,extension=sp.sqrt(3))
print("factorization over Q(sqrt3):")
for f,e in fac[1]:
    fp=sp.Poly(f,y,extension=sp.sqrt(3))
    nr=[complex(r) for r in sp.Poly(sp.N(f,40),y).nroots(n=30)]
    pos=[r.real for r in nr if abs(r.imag)<1e-20 and r.real>0]
    print("  mult %d, degree %d, positive real roots (numerical): %s"%(e,fp.degree(),[round(p,10) for p in pos]))
    print("     factor:",f)
open('cert5_F.txt','w').write(str(F.as_expr()))
