"""Exact profile intrinsicness test by SAT.
For each deterministic local strategy f, ask: is there g in G0 (W(P;g)=0) with a fixed point g(f(x)) = x?
P is profile-intrinsic iff every f admits such a g (no f avoids all of G0)."""
import numpy as np, itertools, sys
from pysat.solvers import Cadical153

src = open('intrinsic5.py').read()
exec(src.split("rng=np.random")[0])   # defines tabs, n, N, al, bigproj, ker

mode = sys.argv[1] if len(sys.argv) > 1 else "special"
if mode == "special":
    psi = np.load("psi_special.npy")
else:
    rng = np.random.default_rng(int(mode))
    psi = ker @ rng.normal(size=ker.shape[1])
psi = psi / np.linalg.norm(psi)
Pt = np.array([[psi @ bigproj(o, x) @ psi for x in range(N)] for o in range(N)])
zero = Pt < 1e-10
print("state:", mode, " zero entries:", int(zero.sum()), flush=True)

def others(o, k):
    return tuple((o >> j) & 1 for j in range(n) if j != k)

var = {}
def V(k, r):
    if (k, r) not in var:
        var[(k, r)] = len(var) + 1
    return var[(k, r)]

base = []
for o in range(N):
    for x in range(N):
        if not zero[o][x]:          # forbid g(o) = x
            base.append([(-V(k, others(o, k)) if (x >> k) & 1 else V(k, others(o, k))) for k in range(n)])
top = len(var)
fs = [lambda b: 0, lambda b: 1, lambda b: b, lambda b: 1 - b]
perfect = 0
nxt = top
with Cadical153(bootstrap_with=base) as so:
    assert so.solve(), "G0 empty"
    for F in itertools.product(range(4), repeat=n):
        nxt += 1; sel = nxt
        axs = []
        for x in range(N):
            nxt += 1; ax = nxt; axs.append(ax)
            o = sum(fs[F[k]]((x >> k) & 1) << k for k in range(n))
            for k in range(n):
                lit = V(k, others(o, k)) if (x >> k) & 1 else -V(k, others(o, k))
                so.add_clause([-ax, lit])
        so.add_clause([-sel] + axs)
        if not so.solve(assumptions=[sel]):
            perfect += 1
print("deterministic strategies avoiding every g in G0:", perfect, "of 1024")
print("=> PROFILE-INTRINSIC (pseudo-telepathy)" if perfect == 0 else "=> not intrinsic")
