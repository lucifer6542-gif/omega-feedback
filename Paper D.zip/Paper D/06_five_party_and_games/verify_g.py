"""Independent check of a feedback given by truth tables g_k(o), o in 0..2^n-1 (bit k = o_k)."""
import numpy as np, itertools
def analyze(tabs):
    n=len(tabs); N=1<<n
    g=np.array(tabs)
    for k in range(n):   # independence of own output
        for o in range(N): assert g[k][o]==g[k][o^(1<<k)], "g_%d depends on o_%d"%(k,k)
    chi=np.array([[(-1)**bin(o&T).count('1') for o in range(N)] for T in range(N)])
    wt=0; targets=set()
    for U in range(1,N):
        if bin(U).count('1')<2: continue
        h=np.zeros(N,int)
        for u in range(n):
            if U>>u&1: h^=g[u]
        f=(-1)**h; fh=chi@f/N
        for T in range(N):
            if (T&U)==U and abs(fh[T])>1e-12:
                wt=max(wt,bin(T).count('1'))
                if bin(U).count('1')==2 and bin(T).count('1')==3: targets.add((T&~U).bit_length()-1)
    return wt,sorted(targets)

if __name__ == "__main__":
    import json, sys
    f = sys.argv[1] if len(sys.argv) > 1 else 'cand1.jsonl'
    tabs = json.loads(open(f).readline())
    wt, targets = analyze(tabs)
    print(f"{f}: Pauli weight {wt}, targets of two-party digons {targets}")
