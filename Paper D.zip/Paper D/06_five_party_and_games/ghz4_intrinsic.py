"""Is the GHZ4 box (sigma_x for x=0, sigma_y for x=1) profile-intrinsic (paper B, Def. 5, extended to n=4)?
Step 1: compute the box P(o|x) exactly from the state.  Step 2: G0 = all GENERAL feedbacks with W(P;g)=0
(brute force over the structure forced by W=0).  Step 3: search all local deterministic boxes L for one with
W(L;g)=0 for every g in G0 (then P is NOT intrinsic)."""
import numpy as np, itertools
n=4; N=16
psi=np.zeros(N,complex); psi[0]=psi[N-1]=1/np.sqrt(2)
X=np.array([[0,1],[1,0]],complex); Y=np.array([[0,-1j],[1j,0]])
def proj(b,x):
    A=X if x==0 else Y; return (np.eye(2)+(-1)**b*A)/2
def P(o,x):
    M=np.array([[1]],complex)
    for k in range(n): M=np.kron(M,proj((o>>(n-1-k))&1,(x>>(n-1-k))&1))
    return float(np.real(psi.conj()@M@psi))
Pt=np.array([[P(o,x) for x in range(N)] for o in range(N)])
assert np.allclose(Pt.sum(0),1)
bit=lambda v,k: (v>>(n-1-k))&1
# Step 2: enumerate ALL general feedbacks with W(P;g)=0 by SAT (g_k depends only on the other three outputs)
from pysat.solvers import Cadical153
def others(o,k): return tuple(bit(o,j) for j in range(n) if j!=k)
var={}
def V(k,r):
    if (k,r) not in var: var[(k,r)]=len(var)+1
    return var[(k,r)]
cls=[]
for o in range(N):
    for x in range(N):
        if Pt[o][x]>1e-12:   # forbid g(o)=x
            cls.append([(-V(k,others(o,k)) if bit(x,k) else V(k,others(o,k))) for k in range(n)])
G0=[]
with Cadical153(bootstrap_with=cls) as so:
    while so.solve():
        m=set(l for l in so.get_model() if l>0)
        gd=[{r:(1 if V(k,r) in m else 0) for (kk,r) in var if kk==k} for k in range(n)]
        G0.append(gd)
        so.add_clause([-v if v in m else v for v in var.values()])
print("|G0| (general feedbacks with W=0):",len(G0))
def g_of(gd,o): 
    x=0
    for k in range(n): x=(x<<1)|gd[k][others(o,k)]
    return x
# Step 3: local deterministic boxes: o_k = f_k(x_k), f_k in {0,1,id,not}
fs=[lambda b:0,lambda b:1,lambda b:b,lambda b:1-b]
witness=[]
for F in itertools.product(range(4),repeat=n):
    def L(x): 
        o=0
        for k in range(n): o=(o<<1)|fs[F[k]](bit(x,k))
        return o
    ok=all(all(g_of(gd,L(x))!=x for x in range(N)) for gd in G0)   # no fixed point for any g in G0
    if ok: witness.append(F)
print("local deterministic witnesses L with W(L;g)=0 for all g in G0:",len(witness))
print("=> GHZ4 box is", "NOT profile-intrinsic" if witness else "PROFILE-INTRINSIC")
