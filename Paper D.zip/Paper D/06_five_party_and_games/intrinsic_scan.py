import numpy as np, itertools, subprocess
exec(open('intrinsic5b.py').read().split("order=np.argsort")[0])
order=np.argsort([-len(m) for m in members]); top=order[:14]
cands=[]
for tri in itertools.combinations(top,3):
    Mx=np.array([dirs[i] for i in tri]); u,s,vt=np.linalg.svd(Mx)
    if s[-1]<1e-8: continue
    c=vt[-1]; nz=48+sum(len(members[i]) for i in range(len(dirs)) if abs(dirs[i]@c)<1e-9)
    key=tuple(np.round(np.abs(c),6))
    cands.append((nz,key,c))
seen=set(); uniq=[]
for nz,key,c in sorted(cands,key=lambda t:-t[0]):
    if key in seen: continue
    seen.add(key); uniq.append((nz,c))
print("distinct special states:",len(uniq))
for i,(nz,c) in enumerate(uniq[:15]):
    np.save('psi_special.npy',ker@c)
    out=subprocess.run(['python3','intrinsic_sat.py','special'],capture_output=True,text=True,timeout=600).stdout
    line=[l for l in out.splitlines() if l.startswith('deterministic')][0]
    print("state %2d: zeros %d  %s"%(i,nz,line),flush=True)
