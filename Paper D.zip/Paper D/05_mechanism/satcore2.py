import sys, itertools, time
from pysat.solvers import Cadical153
n=int(sys.argv[1]); sb=int(sys.argv[2]) if len(sys.argv)>2 else 1
cnt=[0]
def nv():
    cnt[0]+=1; return cnt[0]
M={}
for i in range(n):
    for j in range(n):
        if i!=j: M[(i,j)]=nv()
cl=[]
q={}
def xor_def(z,a,b):
    cl.extend([[-z,a,b],[-z,-a,-b],[z,-a,b],[z,a,-b]])
for u in range(n):
    for S in range(1,1<<n):
        if S>>u&1: continue
        low=S&-S; i=low.bit_length()-1; rest=S^low
        if rest==0: q[(u,S)]=M[(i,u)]
        else:
            z=nv(); xor_def(z,q[(u,rest)],M[(i,u)]); q[(u,S)]=z
for U in range(1,1<<n):
    mem=[u for u in range(n) if U>>u&1]; k=len(mem)
    if k<2: continue
    notall=[-q[(u,U^(1<<u))] for u in mem]
    outs=[v for v in range(n) if not U>>v&1]
    if k>=4: cl.append(notall)
    elif k==3:
        for v in outs: cl.append(notall+[-q[(v,U)]])
    elif k==2:
        for a,b in itertools.combinations(outs,2): cl.append(notall+[-q[(a,U)],-q[(b,U)]])
for i in range(n):
    cl.append([M[(i,j)] for j in range(n) if j!=i])
    cl.append([M[(j,i)] for j in range(n) if j!=i])
if sb:
    # lex-leader for adjacent transpositions: M <=lex P M P^T (row-major order, diagonal skipped)
    pos=[(a,b) for a in range(n) for b in range(n) if a!=b]
    for s in range(n-1):
        sig=lambda x: s+1 if x==s else (s if x==s+1 else x)
        prev=None
        for (a,b) in pos:
            X=M[(a,b)]; Y=M[(sig(a),sig(b))]
            if X==Y: continue
            if prev is None:
                cl.append([-X,Y])
            else:
                cl.append([-prev,-X,Y])
            e=nv()
            if prev is None:
                cl.append([X,Y,e]); cl.append([-X,-Y,e])
            else:
                cl.append([-prev,X,Y,e]); cl.append([-prev,-X,-Y,e])
            prev=e
t=time.time()
s=Cadical153(bootstrap_with=cl)
r=s.solve()
print(n,"sb" if sb else "nosb","SAT" if r else "UNSAT","%.1fs"%(time.time()-t),flush=True)
if r:
    m=set(x for x in s.get_model() if x>0)
    print([sum((1<<j) for j in range(n) if j!=i and M[(i,j)] in m) for i in range(n)])
