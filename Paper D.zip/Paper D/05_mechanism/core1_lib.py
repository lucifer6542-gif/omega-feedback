import itertools
def level_of(M,n):
    w=[0]*(1<<n); L=0
    for U in range(1,1<<n):
        low=U&-U; k=low.bit_length()-1
        w[U]=w[U^low]^M[k]
        if (w[U]&U)==U:
            c=bin(w[U]).count('1')
            if c>L: L=c
    return L
def transpose(M,n):
    return [sum(((M[j]>>k)&1)<<j for j in range(n)) for k in range(n)]
def peel(M,n):
    alive=(1<<n)-1; ch=True
    while ch:
        ch=False
        for k in range(n):
            if not (alive>>k)&1: continue
            row=M[k]&alive
            col=any(((M[j]>>k)&1) for j in range(n) if (alive>>j)&1 and j!=k)
            if row==0 or not col:
                alive&=~(1<<k); ch=True
    return alive
def sub(M,n,alive):
    idx=[k for k in range(n) if (alive>>k)&1]; Ms=[]
    for a,k in enumerate(idx):
        r=0
        for b,j in enumerate(idx):
            if (M[k]>>j)&1: r|=1<<b
        Ms.append(r)
    return Ms,idx
def canon(Ms,m):
    best=None
    for p in itertools.permutations(range(m)):
        rows=[0]*m
        for k in range(m):
            r=0
            for j in range(m):
                if (Ms[k]>>j)&1: r|=1<<p[j]
            rows[p[k]]=r
        t=tuple(rows)
        if best is None or t<best: best=t
    return best
