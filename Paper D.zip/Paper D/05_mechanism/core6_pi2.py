import numpy as np, sys
sys.argv=['x','6']
exec(open('minpi2_n5.py').read().split("t=time.time()")[0])
for rows in [(2,5,25,5,45,5),(2,5,25,5,40,5)]:
    assert weight_ok(list(rows)), rows
    # core check: no zero row, no zero column
    assert all(rows) and all(any(r>>j&1 for r in rows) for j in range(6))
    print(rows, "lambda_min(pi/2) = %.15f"%lam(list(rows)))
print("3/2-sqrt2 = %.15f"%(1.5-np.sqrt(2)))
