#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
typedef uint64_t u64;
#define MAXN 9
static int popc(int x){return __builtin_popcount(x);}
static int ok3(const int *M,int n){
  static int w[1<<MAXN]; w[0]=0;
  for(int U=1;U<(1<<n);U++){int low=U&-U;int k=__builtin_ctz(U);w[U]=w[U^low]^M[k];
    if((w[U]&U)==U && popc(w[U])>3) return 0;}
  return 1;
}
static int peel(const int*M,int n){
  int alive=(1<<n)-1,ch=1;
  while(ch){ch=0;for(int k=0;k<n;k++){if(!((alive>>k)&1))continue;int row=M[k]&alive;int col=0;
    for(int j=0;j<n;j++) if(((alive>>j)&1)&&j!=k&&((M[j]>>k)&1)){col=1;break;}
    if(row==0||!col){alive&=~(1<<k);ch=1;}}}
  return alive;
}
static u64 pack(const int*M,int n){u64 v=0;for(int k=0;k<n;k++)v=(v<<n)|M[k];return v;}
static void unpack(u64 v,int n,int*M){for(int k=n-1;k>=0;k--){M[k]=v&((1<<n)-1);v>>=n;}}
static u64 canon(const int*M,int n){
  int p[MAXN];for(int i=0;i<n;i++)p[i]=i;u64 best=~0ULL;
  while(1){int rows[MAXN];
    for(int k=0;k<n;k++){int r=0;for(int j=0;j<n;j++) if((M[k]>>j)&1) r|=1<<p[j]; rows[p[k]]=r;}
    u64 v=0;for(int k=0;k<n;k++)v=(v<<n)|rows[k]; if(v<best)best=v;
    int i=n-2;while(i>=0&&p[i]>p[i+1])i--; if(i<0)break;
    int j=n-1;while(p[j]<p[i])j--;int t=p[i];p[i]=p[j];p[j]=t;
    for(int a=i+1,b=n-1;a<b;a++,b--){t=p[a];p[a]=p[b];p[b]=t;}}
  return best;
}
typedef struct {u64*t;long cap;long n;} HS;
static void hinit(HS*h,long cap){h->cap=cap;h->t=calloc(cap,sizeof(u64));h->n=0;}
static int hadd(HS*h,u64 v){u64 x=(v+1)*0x9E3779B97F4A7C15ULL;long i=(x>>20)%h->cap;
  while(h->t[i]){if(h->t[i]==v+1)return 0;i=(i+1)%h->cap;} h->t[i]=v+1;h->n++;return 1;}
int main(int argc,char**argv){
  int target=atoi(argv[1]);
  // classes of size 1: single 0 matrix
  u64*cur=malloc(sizeof(u64)); cur[0]=0; long ncur=1; int k=1;
  while(k<target){
    int n=k+1; int last=(n==target);
    HS h; hinit(&h, last? (1<<22) : 40000000); HS hc; hinit(&hc,1<<22);
    long passed=0;
    for(long i=0;i<ncur;i++){
      int B[MAXN]; unpack(cur[i],k,B);
      for(int r=0;r<(1<<k);r++)for(int c=0;c<(1<<k);c++){
        int M[MAXN]; for(int a=0;a<k;a++)M[a]=B[a]|(((c>>a)&1)<<k); M[k]=r;
        if(!ok3(M,n))continue; passed++;
        int al=peel(M,n); int full=(popc(al)==n);
        if(full) hadd(&hc,canon(M,n));
        if(!last) hadd(&h,canon(M,n));
      }
    }
    printf("n=%d: level<=3 extension hits %ld; classes %ld; core classes %ld\n",n,passed,last?-1L:h.n,hc.n);
    fflush(stdout);
    // print core classes
    for(long j=0;j<hc.cap;j++) if(hc.t[j]){int M[MAXN];unpack(hc.t[j]-1,n,M);printf("  CORE%d",n);for(int a=0;a<n;a++)printf(" %d",M[a]);printf("\n");}
    if(last)break;
    // new cur
    ncur=h.n; cur=realloc(cur,sizeof(u64)*ncur); long q=0;
    for(long j=0;j<h.cap;j++) if(h.t[j]) cur[q++]=h.t[j]-1;
    free(h.t); free(hc.t); k=n;
  }
  return 0;
}
