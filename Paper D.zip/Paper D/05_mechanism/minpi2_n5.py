"""lambda_min at alpha=(pi/2)^n over all affine feedbacks of Pauli weight <= 3 (n=5 exhaustive)."""
import numpy as np, itertools, sys, time
n=int(sys.argv[1]) if len(sys.argv)>1 else 5
N=1<<n
pc=[bin(i).count('1') for i in range(N)]
subsets=list(range(1,N))
def weight_ok(rows):
    for U in subsets:
        w=0; ok=True
        for v in range(n):
            if U>>v&1: w^=rows[v]
        if (w&U)==U and pc[w]>3: return False
    return True
c=s=np.sqrt(0.5)
# rotated frame vectors at alpha=pi/2: |b>_1
K1=np.array([[c,-s],[s,c]])  # columns |0>_1,|1>_1
E=np.eye(2)
O=np.arange(N)
BITS=np.array([[o>>k&1 for k in range(n)] for o in range(N)])
def lam(rows):
    X=np.array([[pc[rows[k]&o]&1 for k in range(n)] for o in range(N)])
    # u[o,k,:] = vector of party k (big-endian kron order: party 0 first)
    U=np.where(X[:,:,None]==1, K1.T[BITS], E[BITS])   # K1.T[b] = column b of K1
    V=U[:,0,:]
    for k in range(1,n):
        V=(V[:,:,None]*U[:,k,None,:]).reshape(N,-1)
    V=V.T
    return np.linalg.eigvalsh(V@V.T)[0]
t=time.time(); best=(9,None); cnt=0
offmask=[[j for j in range(n) if j!=k] for k in range(n)]
for bits in range(1<<(n*(n-1))):
    rows=[];b=0
    for k in range(n):
        r=0
        for j in offmask[k]:
            if bits>>b&1: r|=1<<j
            b+=1
        rows.append(r)
    if not weight_ok(rows): continue
    cnt+=1
    l=lam(rows)
    if l<best[0]-1e-12: best=(l,rows)
print("n=%d weight<=3 affine: %d   min lambda %.15f   3/2-sqrt2 %.15f   rows %s   %.0fs"%(n,cnt,best[0],1.5-np.sqrt(2),best[1],time.time()-t))
